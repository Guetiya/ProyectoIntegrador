<?php

mail("dbertin.diet@gmail.com", "Probando email en php", "Esto es una prueba a ver si funciona el mail en php") ;

?>

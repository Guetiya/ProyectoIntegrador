<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Enregistrado</title>
    <link rel="stylesheet" href="css/styles-main.css">

  </head>
  <body>
    <div class="alert alert-success">
      <strong>¡Estás bien registrado sobre nuestro sitio!</strong> para volver a la pagina principal y loggearte haz click <a href=".\login.php" class="alert-link">aquí</a>.
    </div>


    <!-- <h2>¡Estás bien registrado sobre nuestro sitio!
     para volver a la pagina principal y loggearte haz click <a href=".\login.php">aquí</a></h2> -->
  </body>
</html>

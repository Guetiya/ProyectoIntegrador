<?php
require_once ('usuario.php');
require_once ("bd.php");
// require_once ("connect.php");

class BdMYSQL extends Bd
{
  private $connexion;

  public function guardarUsuario(Usuario $usuario){
    $json = json_encode($usuario);
    file_put_contents("users.json", $json . PHP_EOL, FILE_APPEND);
    return $usuario;
  }

  public function __construct(){
    $dsn = 'mysql:host=localhost; dbname=mariage_en_beaute; charset=utf8mb4; port:3306';
    $db_user = 'root';//delphine
    $db_pass = '';//Delphine123Yvan456
    $this->connexion = new PDO($dsn, $db_user, $db_pass);

    try {
    $this->connexion = new PDO($dsn, $db_user, $db_pass);
    }
    catch (PDOException $exception){
      echo $exception->getMessage();
    }
  }


  public function guardarUsuarioBaseDatos(Usuario $usuario){
    $query = $this->connexion->prepare("INSERT INTO users(Apellido, Nombre, Correo, Contraseña)
    VALUES(?,?,?,?)");
    $query->execute(array($_POST['apellido'], $_POST['nombre'], $_POST['correo'], sha1($variable['contrasena'])));
  }
}


 ?>

CREATE TABLE users (
id INT unsigned PRIMARY KEY auto_increment,
Apellido VARCHAR (70) NOT NULL,
Nombre VARCHAR (70) NOT NULL,
Coreo VARCHAR(255) NOT NULL, 
Contraseña VARCHAR(255) NOT NULL
);
